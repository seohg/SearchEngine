import os
import urllib.request as r
import urllib.parse as p
import json
import pandas as pd
import ssl
import re

from app.module import dbModule

db_class = dbModule.Database()

def get_top_5():
    result = db_class.executeAll("SELECT word FROM keyword GROUP BY word ORDER BY SUM(freq) DESC LIMIT 5;")
    words = []
    for i in range (0, 5):
        words.append(result[i]['word'])

    research_title = db_class.executeAll("WITH top (tRID) AS( \
                SELECT RID \
                FROM pub_date \
                ORDER BY year DESC, month DESC, date DESC \
                LIMIT 5 \
            ) \
            SELECT title FROM research, top WHERE research.RID = top.tRID;")
    for i in range(0, 5):
        words.append(research_title[i]['title'])

    print("==", words)
    return words



def get_info(name1):

    result =[]
    rid=name1['title']
    rid = int(rid)

    first = db_class.executeOne(
        "SELECT title, institution_name, WID, research_url FROM research WHERE RID = '%d'" % rid)
    result.append(first['title'])
    result.append(first['institution_name'])


    second = db_class.executeOne("SELECT year, month, date FROM pub_date WHERE RID = '%d'" % rid)
    date = str(second['year']) + '/' + str(second['month']) + '/' + str(second['date'])
    result.append(date)

    third = db_class.executeOne("SELECT writer_name FROM writer WHERE WID = '%d'" % int(first['WID']))
    result.append(third['writer_name'])

    fourth = db_class.executeOne("SELECT body FROM body WHERE RID = '%d'"%rid)
    result.append(fourth['body'])
    result.append(first['research_url'])

    print(result)
    return result
