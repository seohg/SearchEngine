from flask import Flask, render_template, request

app = Flask(__name__)
from app.main.index import main as main
from app.test.test import test as test
import BM25
import top5

app.register_blueprint(test)
app.register_blueprint(main)


@app.route('/')
def first():
    return render_template('first.html')

@app.route('/website',methods=['POST','GET'])
def website():
    result = top5.get_top_5()
    global word1
    word1= result[0]
    global word2
    word2= result[1]
    global word3
    word3= result[2]
    global word4
    word4= result[3]
    global word5
    word5= result[4]
    global up1
    up1= result[5]
    global up2
    up2= result[6]
    global up3
    up3= result[7]
    global up4
    up4= result[8]
    global up5
    up5= result[9]

    return render_template('website.html', word1 = word1, word2 = word2, word3 = word3, word4= word4, word5=word5, up1 = up1, up2=up2, up3=up3, up4=up4, up5=up5)


@app.route('/search',methods=['POST','GET'])
def search():
    title = request.form
    BM25_return = BM25.findDocumentsForQuery(title)

    rid1 = BM25_return[0][0]
    title1 = BM25_return[0][1]
    date1 = BM25_return[0][3]
    winst1 = BM25_return[0][2] + "/" + BM25_return[0][4]

    rid2 = BM25_return[1][0]
    title2 = BM25_return[1][1]
    date2 = BM25_return[1][3]
    winst2 = BM25_return[1][2] + "/" + BM25_return[1][4]

    rid3 = BM25_return[2][0]
    title3 = BM25_return[2][1]
    date3 = BM25_return[2][3]
    winst3 = BM25_return[2][2] + "/" + BM25_return[2][4]

    rid4 = BM25_return[3][0]
    title4 = BM25_return[3][1]
    date4 = BM25_return[3][3]
    winst4 = BM25_return[3][2] + "/" + BM25_return[3][4]

    rid5 = BM25_return[4][0]
    title5 = BM25_return[4][1]
    date5 = BM25_return[4][3]
    winst5 = BM25_return[4][2] + "/" + BM25_return[4][4]

    return render_template("search.html", rid1=rid1, title1=title1, winst1=winst1, date1=date1, rid2=rid2, title2=title2, winst2=winst2, date2=date2, rid3=rid3, title3=title3, winst3=winst3, date3=date3, rid4=rid4, title4=title4, winst4=winst4, date4=date4, rid5=rid5, title5=title5, winst5=winst5, date5=date5, word1 = word1, word2 = word2, word3 = word3, word4= word4, word5=word5, up1 = up1, up2=up2, up3=up3, up4=up4, up5=up5)


@app.route('/info',methods=['POST','GET'])
def info():
    ti = request.form
    result = top5.get_info(ti)
    
    title = result[0]
    winst = result[1] + "/" + result[3]
    date = result[2]
    body = result[4]
    url = result[5]

    return render_template("info.html", title = title, winst = winst, date = date, body = body, word1 = word1, word2 = word2, word3 = word3, word4= word4, word5=word5, up1 = up1, up2=up2, up3=up3, up4=up4, up5=up5, url = url)
